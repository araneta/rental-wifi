<!-- src/pages/Home.vue -->
<template>
  <div>
    <h1>Welcome to Home</h1>
  </div>
</template>
