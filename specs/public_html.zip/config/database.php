<?php
$host = "localhost";
$user = "u293445904_tagihan";
$pass = "Danil123!!";
$dbname = "u293445904_tagihan";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
